import React from "react";

const HomeComp = () => {
  return <div></div>;
};

export default HomeComp;
